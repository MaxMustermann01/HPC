
template <typename DataType,
          int DIMS>			// Number of dimensions of data array
class halo {
  
public:
  
  typedef typename get_dim<DIM>::
  
  explicit halo(MPI_Comm)
};